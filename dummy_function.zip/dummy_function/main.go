package main

import "fmt"

func main() {
	fmt.Println("This is a dummy function!")
}
